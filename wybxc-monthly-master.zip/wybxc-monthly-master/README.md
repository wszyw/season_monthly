<div align="center">

# 忘忧北萱草月刊

来了解一下最新最热的忘忧北萱草月刊吧！

</div>

[![Style](https://img.shields.io/badge/Style-%E5%BF%98%E5%BF%A7%E5%8C%97%E8%90%B1%E8%8D%89-8e48ff)](https://github.com/Wybxc)
[![Love](https://img.shields.io/badge/Love-100%25!-ff69b4)](https://monthly.wybxc.cc)
[![Licence](https://img.shields.io/badge/Licence-CC%20BY--NC--ND%204.0-orange)](https://creativecommons.org/licenses/by-nc-nd/4.0/deed.zh-Hans)

因为想办一个月刊，所以就有了这个项目。

之前也屡次有过建博客的想法，不过每次都因为懒得写文章，所以往往无疾而终。

……好像月刊的形式也不能解决这些问题吧？不过至少我可以光明正大地把一些没写完的东西贴出来了；因为月刊总是需要更新，没写完的就当是连载了。

总之，这依然是一个非常有“忘忧北萱草”的感觉的头脑发热的产物，不过，结果怎么样，还是要试过再说的！

## 许可

<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/"><img alt="知识共享许可协议" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png" /></a>

本作品采用<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/">知识共享署名-非商业性使用-禁止演绎 4.0 国际许可协议</a>进行许可。非商业性转载请注明出处，其他需求请与我们联系。